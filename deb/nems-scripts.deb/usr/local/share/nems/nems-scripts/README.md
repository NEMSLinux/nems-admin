# /usr/local/share/nems/nems-scripts
Scripts located in /usr/local/share/nems/nems-scripts on NEMS 1.2+

These tools help NEMS operate and keep itself up-to-date.

Generally these tools are run during cron operations or when logging in (for the MOTD for example).

PR's welcome.
